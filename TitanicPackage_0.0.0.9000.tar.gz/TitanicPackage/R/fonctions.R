#' Calculer le taux de survie des passagers du Titanic
#'
#' Calcule le pourcentage de survivants selon une variable
#' catégorielle, par exemple le sexe ou la classe.
#'
#' @param donnees Un data.frame contenant les données Titanic.
#' @param variable Nom de la variable de regroupement (caractère).
#'
#' @return Un data.frame avec les effectifs et le taux
#'   de survie en pourcentage pour chaque groupe.
#'
#' @export
#'
#' @examples
#' data("TitanicSurvival", package = "carData")
#' taux_survie(TitanicSurvival, "sex")
#' taux_survie(TitanicSurvival, "passengerClass")

taux_survie <- function(donnees, variable) {
  
  if (!variable %in% names(donnees)) {
    stop("La variable demandée n'existe pas.")
  }
  
  if (!"survived" %in% names(donnees)) {
    stop("La colonne survived est absente.")
  }
  
  resultat <- aggregate(
    donnees$survived == "yes",
    by = list(groupe = donnees[[variable]]),
    FUN = function(x) c(
      effectif = length(x),
      survivants = sum(x),
      taux = mean(x) * 100
    )
  )
  
  data.frame(
    groupe = resultat$groupe,
    effectif = resultat$x[, "effectif"],
    survivants = resultat$x[, "survivants"],
    taux_survie = round(resultat$x[, "taux"], 1)
  )
}

